$(function(){
        $('.css-scrollbar').scrollbar();
        $('.fff').scrollbar();
      })